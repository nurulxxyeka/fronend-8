import React from 'react'
import FEmhs from './component/1-FE-Mhs'



function App() {
  
  return (
    <>
      <FEmhs /> 
    </>
  )
}

export default App
