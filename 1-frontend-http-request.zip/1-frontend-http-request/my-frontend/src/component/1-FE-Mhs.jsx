import { useState, useEffect } from 'react';
import './1-FE-Mhs.css';


const FEmhs = () => {

    const endpoint = "http://localhost:5000/mahasiswa";

    const [getMhs, setGetMhs] = useState([]);
    const [mhsNim, setMhsNim] = useState("");
    const [mhsNama, setMhsNama] = useState("");
    const [mhsAngkatan, setMhsAngkatan] = useState("");
    const [mhsProdi, setMhsProdi] = useState("");


    const inputNim = (e) => {
        setMhsNim(e);
    };
    const inputNama = (e) => {
        setMhsNama(e);
    };
    const inputAngkatan = (e) => {
        setMhsAngkatan(e);
    };
    const inputProdi = (e) => {
        setMhsProdi(e);
    };
    const inputClear = () => {
        setMhsNim("");
        setMhsNama("");
        setMhsAngkatan("");
        setMhsProdi("");
    };


    const fetchGetMhs = async() => {
        const response = await fetch(endpoint);
        const data = await response.json();
        setGetMhs(data);
    }
    
    const fetchGetMhsByNim = async() => {
        const response = await fetch(endpoint+'/'+mhsNim);
        const data = await response.json();
        setGetMhs(data);
    }

    const fetchPostMhs = async() => {

        const newMahasiswa = { nim: mhsNim, 
                               nama: mhsNama, 
                               angkatan: mhsAngkatan, 
                               prodi: mhsProdi };

        const response = await fetch(endpoint, {
            method: 'post',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newMahasiswa)
        });
        alert('Mahasiswa berhasil ditambahkan:]!');
        inputClear();  
        fetchGetMhs();      
    }

    const fetchPutMhs = async() => {

        const newMahasiswa = { nim: mhsNim, 
                               nama: mhsNama, 
                               angkatan: mhsAngkatan, 
                               prodi: mhsProdi };

        const response = await fetch(endpoint+'/'+mhsNim, {
            method: 'put',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newMahasiswa)
        });
        alert('Mahasiswa berhasil diubah!');
        inputClear();  
        fetchGetMhs();      
    }

    const fetchDeleteMhs = async() => {

        const response = await fetch(endpoint+'/'+mhsNim, {
            method: 'delete',
        });
        alert('Mahasiswa berhasil dihapus!');
        inputClear();  
        fetchGetMhs();      
    }

    useEffect(() => {
        fetchGetMhs();
    }, [])

    return (
        <>
            
            <div className="container">
                <h1>DATA MAHASISWA</h1> 
                <label>NIM: </label>
                <input type="text" value={mhsNim}
                       onChange={(e) => inputNim(e.target.value)}></input>

                <label>NAMA: </label>
                <input type="text" value={mhsNama}
                       onChange={(e) => inputNama(e.target.value)}></input>

                <label>ANGKATAN:</label>
                <input type="text" value={mhsAngkatan}
                       onChange={(e) => inputAngkatan(e.target.value)}></input>

                <label>PRODI:</label>
                <input type="text" value={mhsProdi}
                       onChange={(e) => inputProdi(e.target.value)}></input>

                <div>
                    <button onClick={fetchGetMhs}> GET ALL</button>
                    <button onClick={fetchGetMhsByNim}> GET BY NIM</button>
                    <button onClick={fetchPostMhs}> POST</button>
                    <button onClick={fetchPutMhs}> PUT</button>
                    <button onClick={fetchDeleteMhs}> DELETE</button>
                    <button onClick={inputClear}> CLEAR</button>
                </div>

                <br></br><br></br><br></br>

                <h1>TABEL MAHASISWA</h1>                
                <table>
                    <thead>
                        <tr>
                            <th>NIM</th>
                            <th>NAMA</th>
                            <th>ANGKATAN</th>
                            <th>PRODI</th>
                        </tr>
                    </thead>
                    <tbody>
                        {getMhs.map((dataMhs) => {
                            return (
                            <tr key={dataMhs.nim}>
                                <td>{dataMhs.nim}</td>
                                <td>{dataMhs.nama}</td>
                                <td>{dataMhs.angkatan}</td>
                                <td>{dataMhs.prodi}</td>
                            </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </>
    );
};

export default FEmhs;