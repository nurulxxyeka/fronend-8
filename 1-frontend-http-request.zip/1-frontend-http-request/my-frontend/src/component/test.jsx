import React, { useState, useEffect } from 'react';

// Endpoint API
const endpoint = "http://localhost:5000/mahasiswa";

const Mahasiswa = () => {
    const [mhs, setMhs] = useState([]);
    const [nim, setNim] = useState('');
    const [nama, setNama] = useState('');
    const [jurusan, setJurusan] = useState('');
    const [id, setId] = useState(null);  // ID untuk update
    const [searchNim, setSearchNim] = useState('');
    const [searchResult, setSearchResult] = useState(null);

    // Fetch data mahasiswa
    const fetchUser = async () => {
        try {
            const response = await fetch(endpoint);
            if (response.ok) {
                const data = await response.json();
                setMhs(data);
            } else {
                console.error('Gagal mengambil data mahasiswa:', response.statusText);
            }
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
        }
    };

    useEffect(() => {
        fetchUser();
    }, []);

    // Tambah mahasiswa
    const addMahasiswa = async (e) => {
        e.preventDefault();
        try {
            const newMahasiswa = { nama, nim, jurusan };
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newMahasiswa),
            });

            if (response.ok) {
                const data = await response.json();
                console.log('Mahasiswa berhasil ditambahkan:', data);
                fetchUser();  // Refresh data
                setNama('');
                setNim('');
                setJurusan('');
            } else {
                console.error('Gagal menambahkan mahasiswa:', response.statusText);
            }
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
        }
    };

    // Update mahasiswa
    const updateMahasiswa = async (e) => {
        e.preventDefault();
        try {
            const updatedMahasiswa = { nama, nim, jurusan };
            const response = await fetch(`${endpoint}/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updatedMahasiswa),
            });

            if (response.ok) {
                const data = await response.json();
                console.log('Mahasiswa berhasil diperbarui:', data);
                fetchUser();  // Refresh data
                setId(null);
                setNama('');
                setNim('');
                setJurusan('');
            } else {
                console.error('Gagal memperbarui mahasiswa:', response.statusText);
            }
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
        }
    };

    // Hapus mahasiswa
    const deleteMahasiswa = async (id) => {
        try {
            const response = await fetch(`${endpoint}/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                console.log('Mahasiswa berhasil dihapus');
                fetchUser();  // Refresh data
            } else {
                console.error('Gagal menghapus mahasiswa:', response.statusText);
            }
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
        }
    };

    // Cari mahasiswa berdasarkan NIM
    const getMahasiswaByNIM = async () => {
        try {
            const response = await fetch(`${endpoint}?nim=${searchNim}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                const data = await response.json();
                setSearchResult(data);
                console.log('Data mahasiswa:', data);
            } else {
                console.error('Gagal mengambil data mahasiswa:', response.statusText);
                setSearchResult(null);
            }
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
            setSearchResult(null);
        }
    };

    return (
        <div>
            <h1>Daftar Mahasiswa</h1>

            {/* Form untuk menambah atau memperbarui mahasiswa */}
            <form onSubmit={id ? updateMahasiswa : addMahasiswa}>
                <h2>{id ? 'Update Mahasiswa' : 'Tambah Mahasiswa'}</h2>
                <div>
                    <label>NIM:</label>
                    <input
                        type="text"
                        value={nim}
                        onChange={(e) => setNim(e.target.value)}
                        disabled={id !== null}  // Disable NIM input saat update
                    />
                </div>
                <div>
                    <label>Nama:</label>
                    <input
                        type="text"
                        value={nama}
                        onChange={(e) => setNama(e.target.value)}
                    />
                </div>
                <div>
                    <label>Jurusan:</label>
                    <input
                        type="text"
                        value={jurusan}
                        onChange={(e) => setJurusan(e.target.value)}
                    />
                </div>
                <button type="submit">{id ? 'Update' : 'Tambah'}</button>
            </form>

            {/* Form untuk mencari mahasiswa berdasarkan NIM */}
            <div>
                <h2>Cari Mahasiswa berdasarkan NIM</h2>
                <input
                    type="text"
                    value={searchNim}
                    onChange={(e) => setSearchNim(e.target.value)}
                    placeholder="Masukkan NIM"
                />
                <button onClick={getMahasiswaByNIM}>Cari</button>
                {searchResult && (
                    <div>
                        <h3>Hasil Pencarian</h3>
                        <p><strong>NIM:</strong> {searchResult.nim}</p>
                        <p><strong>Nama:</strong> {searchResult.nama}</p>
                        <p><strong>Jurusan:</strong> {searchResult.jurusan}</p>
                    </div>
                )}
            </div>

            {/* Daftar mahasiswa */}
            <ul>
                {mhs.map((mahasiswa) => (
                    <li key={mahasiswa.id}>
                        {mahasiswa.nim} - {mahasiswa.nama} - {mahasiswa.jurusan}
                        <button onClick={() => { setId(mahasiswa.id); setNim(mahasiswa.nim); setNama(mahasiswa.nama); setJurusan(mahasiswa.jurusan); }}>Edit</button>
                        <button onClick={() => deleteMahasiswa(mahasiswa.id)}>Hapus</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Mahasiswa;
